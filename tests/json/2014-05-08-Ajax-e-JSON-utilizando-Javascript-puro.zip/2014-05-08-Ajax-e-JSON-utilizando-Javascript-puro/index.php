<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		
		<title>Demo</title>
		<script src="meu_arquivo_javascript.js"></script>
	</head>

	<body>
		<a href="" id="a">Clique</a>
		<div id="texto"></div>
	</body>
</html>